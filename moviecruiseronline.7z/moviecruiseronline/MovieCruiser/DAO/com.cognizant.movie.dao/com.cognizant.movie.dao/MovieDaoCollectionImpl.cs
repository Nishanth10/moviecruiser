﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.movie.model;
using com.cognizant.movie.util;

namespace com.cognizant.movie.dao
{
    public class MovieDaoCollectionImpl : IMovieDao
    {
        private static List<Movie> _movieList;

        public MovieDaoCollectionImpl()
        {
            if(_movieList==null)
            {
                _movieList = new List<Movie>();
                Movie movie1 = new Movie(1001, "Avengers", 356000000f, true,
                    DateUtil.convertToDate("26/08/2019"), "Action", true);
                Movie movie2 = new Movie(1002, "Aladdin", 183000000f, true,
                    DateUtil.convertToDate("24/09/2019"), "Adventure", false);
                Movie movie3 = new Movie(1003, "Captain Marvel", 175000000f, true,
                    DateUtil.convertToDate("08/03/2019"), "Action", false);
                Movie movie4 = new Movie(1004, "The Lion King", 45000000f, false,
                    DateUtil.convertToDate("17/07/2019"), "Animation", true);
                Movie movie5 = new Movie(1005, "First Man", 70000000f, true,
                    DateUtil.convertToDate("29/08/2018"), "Action", true);

                _movieList.Add(movie1);
                _movieList.Add(movie2);
                _movieList.Add(movie3);
                _movieList.Add(movie4);
                _movieList.Add(movie5);

            }

        }

        public List<Movie> getMovieListAdmin()
        {
            return _movieList;
        }

        public List<Movie> getMovieListCustomer()
        {
            List<Movie> filteredList = new List<Movie>();
            foreach (Movie movie in _movieList)
            {
                if (movie.DateOfLaunch > DateTime.Now && movie.Active)
                {
                    filteredList.Add(movie);
                }

            }
            return filteredList;
        }

        public void modifyMovie(Movie movie)
        {
            for (int i = 0; i < _movieList.Count; i++)
            {
                if (_movieList[i].Id == movie.Id) 
                {
                    _movieList[i] = movie;
                    break;
                }

            }
        }

        public Movie getMovie(long movieId)
        {
            Movie movies = null;
            foreach (Movie movie in _movieList)
            {
                if (movie.Id == movieId)
                {
                    movies = movie;
                    break;
                }
            }
            return movies;
        }

    }
}
